package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.entity.Student;
import com.app.repository.StudentRepository;

@Service
@Transactional
public class StudentServiceClass implements StudentService {
    @Autowired
	private StudentRepository stdRepo;
    
	@Override
	public List<Student> getAllStudents() {
		// TODO Auto-generated method stub
		return stdRepo.findAll();
	}

	@Override
	public Student addAllStudents(Student std) {
		// TODO Auto-generated method stub
		return stdRepo.save(std);
	}

	@Override
	public String deleteStudent(Integer stdid) {
		String mesg = "Student deletion failed!!!";
		
		if(stdRepo.existsById(stdid))
		{
			stdRepo.deleteById(stdid);
			mesg = "Student deletion successfully!!!";
		}
		return mesg;
		
	}

	@Override
	public Student updateStudent(Student std) {
		if(stdRepo.existsById(std.getId()))
		{
			return stdRepo.save(std);
		}
		throw new RuntimeException("NO ID FOUND..");
	}

	@Override
	public Student getStudByEmailAndPass(String email, String Password) {
		
		return stdRepo.findByEmailAndPassword(email, Password);
	}
	
	

	

}
