package com.app.service;

import java.util.List;

import com.app.entity.Student;

public interface StudentService {
	
	List<Student> getAllStudents();
	
	Student addAllStudents(Student std);
	
	String deleteStudent(Integer stdid);
	
	Student updateStudent(Student std);

	Student getStudByEmailAndPass(String email, String Password);
}
