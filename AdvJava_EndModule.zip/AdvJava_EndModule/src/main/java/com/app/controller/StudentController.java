package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.entity.Student;
import com.app.service.StudentService;

@RestController
@RequestMapping("/student")
public class StudentController {
	
	@Autowired
	private StudentService studser;
	
	@GetMapping("/getall")
	public List<Student> fetchallStudents()
	{
		return studser.getAllStudents();
	}
	
	@PostMapping("/add")
	public Student insertAllStudents(@RequestBody Student stdt) 
	{
		return studser.addAllStudents(stdt);
	}
	
	@DeleteMapping("/delete/{stdid}")
	public String deleteStudent(@PathVariable Integer stdid)
	{
		return studser.deleteStudent(stdid);
	}
	
	@PutMapping("/update")
	public Student updateStudent(@RequestBody Student std)
	{
		return studser.updateStudent(std);
	}
	
	@PostMapping("/{email}/{password}")
	public Student getByEmailAndPassword(@PathVariable String email, @PathVariable String password) {
		return studser.getStudByEmailAndPass(email, password);
	}
	
	
	

}
